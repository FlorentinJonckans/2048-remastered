#!/usr/bin/python3
# -*- coding: utf-8 -*-
#

import sys

from menu import *
from Jouer import *
from Tutoriel import *

'''
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtMultimedia import *
'''
app = Application(sys.argv)
win = Window()


sys.exit(app.exec_())
